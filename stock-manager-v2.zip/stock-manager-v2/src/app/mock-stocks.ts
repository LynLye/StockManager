// mock stock history

import {Stock} from './stock';
export const MOCKSTOCKS: Stock[] = [
    {cmp: 'APPL'},
    {cmp: 'IBM'},
    {cmp: 'abs'},
    {cmp: 'cds'}
];


