export class Stock {
    cmp: string;
}
